boot <-
function(x,  ...)
{
  UseMethod("boot")

}

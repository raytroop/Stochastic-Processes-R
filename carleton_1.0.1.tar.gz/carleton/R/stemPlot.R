stemPlot <-
function(x, ...)
{
  UseMethod("stemPlot")

}

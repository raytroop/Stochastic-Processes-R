permTest <-
function(x, ...){

UseMethod("permTest")

}

groupedBar <-
function(x, ...)
{
  UseMethod("groupedBar")

}
